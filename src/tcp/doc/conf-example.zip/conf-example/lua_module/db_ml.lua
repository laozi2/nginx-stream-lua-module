--db_ml module
--need mysql.lua, 

local _M = {_VERSION = '0'}
local mt = {__index = _M}

local LOCK_EXPTIME = 5
local LOCK_TIMEOUT = 5
local DB_TIMEOUT = 5000
local DB_MAX_IDLE_TIME = 60000
local DB_POOL_SIZE = 10

local tcp_return = function(body)
    if body then ngx.print(body) end
    ngx.exit()
end

function _M.new()
    local db, err = mysql:new()
    if not db then
        local error_string = "failed to instantiate mysql: " .. tostring(err)
        --nlog.derror(error_string)
        ngx.log(ngx.ERR,error_string)
        tcp_return(error_string)
    end
    
    local self = {mysql = db}
    return setmetatable(self, mt)
end

function _M.connect(self, db_param)
    local res, err, errno, sqlstate = self["mysql"]:connect(db_param)
    self.db_host = db_param.host
    if not res then
        local error_string = "failed to connect: " .. tostring(err)
        --nlog.derror(error_string)
        ngx.log(ngx.ERR,error_string)
        tcp_return(error_string)
    end
end

function _M.query(self, sql)
    local start = ngx.now()
    local res, err, errno, sqlstate = self["mysql"]:query(sql)
    self.elapsed_sql = ngx.now() - start
    
    --nlog.sql(self.db_host, self.elapsed_lock, string.format("%.3f", self.elapsed_sql), sql)
    ngx.log(ngx.INFO,string.format("%.3f", self.elapsed_sql).." "..sql)

    if not res then 
        ---nlog.derror("bad result: " .. err .. ":" .. sql)
        ngx.log(ngx.ERR,"bad result: err[" .. tostring(err).."],errno["..tostring(errno).."],sqlstate["..tostring(sqlstate).."]")
    end

    return res,err, errno, sqlstate
end

function _M.set_keepalive(self)
    local ok, err = self["mysql"]:set_keepalive(DB_MAX_IDLE_TIME, DB_POOL_SIZE)
    if not ok then
        --nlog.derror("failed to set keepalive: ", err)
        ngx.log(ngx.ERR,"failed to set keepalive: " .. tostring(err))
    end
end

function _M.set_timeout(self)
    self["mysql"]:set_timeout(DB_TIMEOUT)
end

function _M.done(self, opts)
    self:set_keepalive()
end

function _M.init(self, opts)
    local db_param = opts.db_param

    self:set_timeout()

    self:connect(db_param)
end

return _M
